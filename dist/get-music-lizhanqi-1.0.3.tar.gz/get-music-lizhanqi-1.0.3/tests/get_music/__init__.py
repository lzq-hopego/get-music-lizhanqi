from get_music import kugou
from get_music import download
from get_music import migu
from get_music import kuwo
from get_music import netease
from get_music import qq
from get_music import oneting
from get_music import fivesing
from get_music import baidu
from rich.console import Console
txt='''
                __                                  __        
   ____   _____/  |_            _____  __ __  _____|__| ____  
  / ___\_/ __ \   __\  ______  /     \|  |  \/  ___/  |/ ___\ 
 / /_/  >  ___/|  |   /_____/ |  Y Y  \  |  /\___ \|  \  \___ 
 \___  / \___  >__|           |__|_|  /____//____  >__|\___  >
/_____/      \/                     \/           \/        \/

'''
console=Console()
console.print(txt,style='bold green')
