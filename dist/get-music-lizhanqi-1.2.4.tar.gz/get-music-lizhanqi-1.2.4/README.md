# get-music-lizhanqi
- 这是一个可以下载和搜索音乐的python命令行工具，支持，酷狗，酷我，百度，网易云，咪咕，qq音乐，5sing，欢迎前来学习的指点

## 使用方法
- 长话短说**get-music -help**或**get-music-lizhanqi -help**打开帮助，帮助里面有全部命令的介绍，或者前往github地址:<https://github.com/lzq-hopego/get-music-lizhanqi>


## 更新记录
- 2023-1-16 完成v1.2.4版本,支持搜索5sing的伴奏数据
> 可以搭配"get-music -r"进行批量搜索，第三个参数是bz代表着5sing伴奏
```
爱人错过,1,bz
```




## THE END
- 本脚本仅支持学习使用，如有发现有任何商业用途，一经发现您将受到法律责任。
- 本程序使用的接口全部来源于网络，切不可有任何商业用途，或我程序中有涉及你公司利益的，你可以联系我，我会及时删除源代码，并不再更新。
- **禁止将本工具用于商业用途**，如产生法律纠纷与本人无关，如有侵权，请联系我删除。
- 如果你对界面设计感兴趣可以去看我的另一篇pyqt5对接的get-music-lizhanqi做的音乐下载播放ui，地址：https://github.com/lzq-hopego/get-music-lizhanqi-gui
- 项目创建者：李先生
- 项目维护者：李先生
- 维护者邮箱：3101978435@qq.com